# Lab 2
welcome to lab 2
In this lab we will be learning about the following:
* How to use list view
* how to use Combo Box
* How to use Slider
* Use of split plane, vBox view