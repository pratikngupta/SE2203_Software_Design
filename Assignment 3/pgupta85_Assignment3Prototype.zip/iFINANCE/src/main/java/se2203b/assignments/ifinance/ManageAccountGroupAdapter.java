package se2203b.assignments.ifinance;

public class ManageAccountGroupAdapter {
}
